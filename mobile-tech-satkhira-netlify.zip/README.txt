Mobile Tech Satkhira website

Netlify deployment: upload this folder's contents, or upload the ZIP file.
Main website file: index.html
Note: Tailwind CSS, Font Awesome and Google Fonts load from their CDNs, so an internet connection is required.
